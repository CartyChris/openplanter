declare module "cytoscape-fcose" {
  const ext: cytoscape.Ext;
  export default ext;
}

declare module "cytoscape-dagre" {
  const ext: cytoscape.Ext;
  export default ext;
}
